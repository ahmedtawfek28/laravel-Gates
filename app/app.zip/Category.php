<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    //

    protected $fillable = ['title','description'];
    public function sub_category() 
	{
	  return $this->hasMany('App\sub_category');
	}
}
