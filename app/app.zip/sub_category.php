<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class sub_category extends Model
{
    protected $fillable = ['title','description','category_id'];
    public function Category() 
	{
		return $this->belongsTo('App\Category');
	}
}
