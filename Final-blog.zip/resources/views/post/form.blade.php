	        	<div class="form-group">
		        	<label for="title">الصنف</label>
		        	<input type="text" class="form-control" name="title" id="title">
	        	</div>
	        	<div class="form-group">
	        		<label for="content">السعر</label>
		        	<input type="content" class="form-control" name="content" id="content">

				</div>
				