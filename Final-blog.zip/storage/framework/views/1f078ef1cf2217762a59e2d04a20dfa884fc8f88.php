<?php $__env->startSection('content'); ?>
<thead>
		<tr>
				<th>S.No</th>
				<th>الصنف</th>
                <th>السعر</th>
          <th>توفيق</th>
                         <th>مهدي </th>
                 <th>رمضان </th>
                                <th>سعد</th>
                                <th>سامي</th>
                                <th>شريف</th>
                                <th>ايمان</th>
                                <th>الاء</th>
                                <th></th>
                                <th></th>
                                <th>السعر </th>
                                <th>Actions</th>
		</tr>
		
</thead>

<tbody>

		<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr><td><?php echo e($loop->index + 1); ?></td>
						<td><?php echo e($Post->title); ?></td>
						<td><?php echo e(substr($Post->content,0,25)); ?>

								<?php if(strlen($Post->content)>25): ?>
								[..]
								<?php endif; ?>
				</td>
				<td class="text-center"><input type="checkbox" class="published" data-id="<?php echo e($Post->id); ?>" <?php if($Post->is_published): ?> checked <?php endif; ?>></td>
				<td class="text-center"><input type="checkbox" class="published2" data-id="<?php echo e($Post->id); ?>" <?php if($Post->is_published2): ?> checked <?php endif; ?>></td>
                <td class="text-center"><input type="checkbox" class="published3" data-id="<?php echo e($Post->id); ?>" <?php if($Post->is_published3): ?> checked <?php endif; ?>></td>
                <td class="text-center"><input type="checkbox" class="published4" data-id="<?php echo e($Post->id); ?>" <?php if($Post->is_published4): ?> checked <?php endif; ?>></td>
                <td class="text-center"><input type="checkbox" class="published5" data-id="<?php echo e($Post->id); ?>" <?php if($Post->is_published5): ?> checked <?php endif; ?>></td>
                <td class="text-center"><input type="checkbox" class="published6" data-id="<?php echo e($Post->id); ?>" <?php if($Post->is_published6): ?> checked <?php endif; ?>></td>
                <td class="text-center"><input type="checkbox" class="published7" data-id="<?php echo e($Post->id); ?>" <?php if($Post->is_published7): ?> checked <?php endif; ?>></td>
                <td class="text-center"><input type="checkbox" class="published8" data-id="<?php echo e($Post->id); ?>" <?php if($Post->is_published8): ?> checked <?php endif; ?>></td>
                <td class="text-center"><input type="checkbox" class="published9" data-id="<?php echo e($Post->id); ?>" <?php if($Post->is_published9): ?> checked <?php endif; ?>></td>
                <td class="text-center"><input type="checkbox" class="published10" data-id="<?php echo e($Post->id); ?>" <?php if($Post->is_published10): ?> checked <?php endif; ?>></td>
		
<td><?php echo e(substr($Post->item,0,4)); ?></td> 
						<td>
								<button class="btn btn-info" data-mytitle="<?php echo e($Post->title); ?>" data-mycontent="<?php echo e($Post->content); ?>" data-myid=<?php echo e($Post->id); ?> data-toggle="modal" data-target="#edit">Edit</button>
								
								<button class="btn btn-danger" data-myid=<?php echo e($Post->id); ?> data-toggle="modal" data-target="#delete">Delete</button>
						</td>
				</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		
</tbody>
<tfoot>
		<tr>
						<th>S.No</th>
						<th>الصنف</th>
                            <?php $__currentLoopData = $counts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th><?php echo e($count->sum); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $is_publisheds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $is_published): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th><?php echo e(substr($is_published->is_published_sum,0,4)); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $is_published2s; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $is_published2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th><?php echo e(substr($is_published2->is_published_sum,0,4)); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $is_published3s; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $is_published3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th><?php echo e(substr($is_published3->is_published_sum,0,4)); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $is_published4s; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $is_published4): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th><?php echo e(substr($is_published4->is_published_sum,0,4)); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $is_published5s; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $is_published5): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th><?php echo e(substr($is_published5->is_published_sum,0,4)); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $is_published6s; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $is_published6): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th><?php echo e(substr($is_published6->is_published_sum,0,4)); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $is_published7s; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $is_published7): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th><?php echo e(substr($is_published7->is_published_sum,0,4)); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $is_published8s; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $is_published8): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th><?php echo e(substr($is_published8->is_published_sum,0,4)); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $is_published9s; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $is_published9): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th><?php echo e(substr($is_published9->is_published_sum,0,4)); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $is_published10s; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $is_published10): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th><?php echo e(substr($is_published10->is_published_sum,0,4)); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <th> </th>
                            <th>Actions</th>
		</tr>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('model'); ?>
<?php echo $__env->make('post.model', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('ajax'); ?>
<?php echo $__env->make('post.ajax', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>