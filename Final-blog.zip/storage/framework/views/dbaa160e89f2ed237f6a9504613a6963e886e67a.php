<?php $__env->startSection('content'); ?>
<thead>
		<tr>
				<th>S.No</th>
				<th>Title</th>
				<th>Content</th>
				<th>Published?</th>
				<th>created_AT</th>
				
				<th>Action</th>
		</tr>
		
</thead>

<tbody>

		<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr><td><?php echo e($loop->index + 1); ?></td>
						<td><?php echo e($Category->title); ?></td>
						<td><?php echo e(substr($Category->content,0,25)); ?>

								<?php if(strlen($Category->content)>25): ?>
								[..]
								<?php endif; ?>
				</td>
				<td class="text-center"><input type="checkbox" class="published" data-id="<?php echo e($Category->id); ?>" <?php if($Category->is_published): ?> checked <?php endif; ?>></td>
                                   
				<td><?php echo e($Category->updated_at); ?></td>
						<td>
								<button class="btn btn-info" data-mytitle="<?php echo e($Category->title); ?>" data-mycontent="<?php echo e($Category->content); ?>" data-myid=<?php echo e($Category->id); ?> data-toggle="modal" data-target="#edit">Edit</button>
								
								<button class="btn btn-danger" data-myid=<?php echo e($Category->id); ?> data-toggle="modal" data-target="#delete">Delete</button>
						</td>
				</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		
</tbody>
<tfoot>
		<tr>
						<th>S.No</th>
				<th>Title</th>
				<th>Content</th>
				<th>Published?</th>
				<th>created_AT</th>
				<th>Action</th>
		</tr>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('model'); ?>
<?php echo $__env->make('post.model', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('ajax'); ?>
<?php echo $__env->make('post.ajax', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>