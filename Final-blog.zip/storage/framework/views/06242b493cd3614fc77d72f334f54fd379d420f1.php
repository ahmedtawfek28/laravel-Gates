	        	<div class="form-group">
		        	<label for="title">Title</label>
		        	<input type="text" class="form-control" name="title" id="title">
	        	</div>
				<div class="form-group">
		        	<label for="slug">slug</label>
		        	<input type="text" class="form-control" name="slug" id="slug">
	        	</div>
                
	        	<div class="form-group">
	        		<label for="content">content</label>
	        		<textarea name="content" id="content" cols="20" rows="5" id='content' class="form-control"></textarea>
				</div>
				