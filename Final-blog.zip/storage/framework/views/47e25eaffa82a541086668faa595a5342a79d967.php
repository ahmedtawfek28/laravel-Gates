	        	<div class="form-group">
		        	<label for="title">Title</label>
		        	<input type="text" class="form-control" name="title" id="title">
	        	</div>
				<div class="form-group">
		        	<label for="slug">slug</label>
		        	<input type="text" class="form-control" name="slug" id="slug">
	        	</div>
                <!-- <div class="form-group">
						<label for="category_id">category_id</label>
						<input type="text" class="form-control" name="category_id" id="category_id">
					</div> -->

		<label for="category_id" class="col-2 col-form-label">category</label>
     <div class="col-13">
<select class="custom-select col-12" name="category_id" id="category_id">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<option value="<?php echo e($Category->id); ?>"><?php echo e($Category->title); ?></option>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                
                                            </select>
                                        </div>
	        	<div class="form-group">
	        		<label for="content">content</label>
	        		<textarea name="content" id="content" cols="20" rows="5" id='content' class="form-control"></textarea>
				</div>
				