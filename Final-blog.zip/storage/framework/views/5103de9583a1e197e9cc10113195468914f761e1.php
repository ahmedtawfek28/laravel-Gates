<script type="text/javascript" src="<?php echo e(asset('Backend/icheck/icheck.min.js')); ?>"></script>

<script>
        $(window).load(function(){
            $('#postTable').removeAttr('style');
        })
    </script>

<script>
        $(document).ready(function(){
            $('.published').iCheck({
                checkboxClass: 'icheckbox_square-yellow',
                radioClass: 'iradio_square-yellow',
                increaseArea: '20%'
            });
            $('.published').on('ifClicked', function(event){
                id = $(this).data('id');
                $.ajax({
                    type: 'POST',
                    url: "<?php echo e(URL::route('changeStatus')); ?>",
                    data: {
                        '_token': $('input[name=_token]').val(),
                        'id': id
                    },
                    success: function(data) {
                     
                    },
                });
            });
            $('.published').on('ifToggled', function(event) {
                $(this).closest('tr').toggleClass('warning');
            });
        });

    </script>
<script>
       

  
        $('#edit').on('show.bs.modal', function (event) {
      
            var button = $(event.relatedTarget) 
            var title = button.data('mytitle') 
            var slug = button.data('myslug') 
            var content = button.data('mycontent') 
            var id = button.data('myid') 
            var modal = $(this)
      
            modal.find('.modal-body #title').val(title);
            modal.find('.modal-body #slug').val(slug);
            modal.find('.modal-body #content').val(content);
            modal.find('.modal-body #id').val(id);
      })
      
      
        $('#delete').on('show.bs.modal', function (event) {
      
            var button = $(event.relatedTarget) 
      
            var id = button.data('myid') 
            var modal = $(this)
      
            modal.find('.modal-body #id').val(id);
      })
      
      
 </script>