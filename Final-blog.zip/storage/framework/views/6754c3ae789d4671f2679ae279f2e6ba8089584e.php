<?php $__env->startSection('content'); ?>
<thead>
		<tr>
				<th>S.No</th>
				<th>Title</th>
				<th>Slug</th>
				<th>Content</th>
				<th>Category</th>
				<th>updateted_AT</th>
				
				<th>Action</th>
		</tr>
		
</thead>

<tbody>

		<?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $SubCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr><td><?php echo e($loop->index + 1); ?></td>
						<td><?php echo e($SubCategory->title); ?></td>
						<td><?php echo e($SubCategory->slug); ?></td>
						<td><?php echo e(substr($SubCategory->content,0,25)); ?>

								<?php if(strlen($SubCategory->content)>25): ?>
								[..]
								<?php endif; ?>
						</td>
						
						      <td><?php echo e($SubCategory->category_title); ?></td>
							
						
			         	<td><?php echo e($SubCategory->updated_at); ?></td>
						<td>
								<button class="btn btn-info" data-mytitle="<?php echo e($SubCategory->title); ?>"data-myslug="<?php echo e($SubCategory->slug); ?>" data-mycontent="<?php echo e($SubCategory->content); ?>" data-myid=<?php echo e($SubCategory->id); ?> data-mycategory_id=<?php echo e($SubCategory->category_id); ?> data-toggle="modal" data-target="#edit">Edit</button>
								
								<button class="btn btn-danger" data-myid=<?php echo e($SubCategory->id); ?> data-toggle="modal" data-target="#delete">Delete</button>
						</td>
				</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		
</tbody>
<tfoot>
		<tr>
						<th>S.No</th>
				        <th>Title</th>
				        <th>Slug</th>
				        <th>Content</th>
				        <th>Category</th>
				        <th>updateted_AT</th>
			        	<th>Action</th>
		</tr>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('model'); ?>
<?php echo $__env->make('subcategory.model', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('ajax'); ?>
<?php echo $__env->make('subcategory.ajax', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>