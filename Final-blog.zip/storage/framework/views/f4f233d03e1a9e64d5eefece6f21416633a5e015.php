<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('images/favicon.jpg')); ?>">

    <!-- CSFR token for ajax call -->
    <meta name="_token" content="<?php echo e(csrf_token()); ?>"/>

    <title>Manage Posts</title>
    
    
    <!-- icheck checkboxes -->
    <link rel="stylesheet" href="<?php echo e(asset('icheck/square/yellow.css')); ?>">
   
</head>

<body>
    <div class="col-md-8 col-md-offset-2">
        <h2 class="text-center">Manage Posts</h2>
        <br />

            <div class="panel-body">
                    <table class="table table-striped table-bordered table-hover" id="postTable" style="visibility: hidden;">
                        <thead>
                            <tr>
                                <th valign="middle">#</th>
                               
                                <th>Published?</th>
                               
                           
                            </tr>
                            <?php echo e(csrf_field()); ?>

                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $indexKey => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="item<?php echo e($post->id); ?> <?php if($post->is_published): ?> warning <?php endif; ?>">
                                    <td class="col1"><?php echo e($indexKey+1); ?></td>
                                    <td class="text-center"><input type="checkbox" class="published" id="" data-id="<?php echo e($post->id); ?>" <?php if($post->is_published): ?> checked <?php endif; ?>></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
            </div><!-- /.panel-body -->
        </div><!-- /.panel panel-default -->
    </div><!-- /.col-md-8 -->

       <!-- jQuery -->
 
    <script src="https://code.jquery.com/jquery-2.2.4.js" integrity="sha256-iT6Q9iMJYuQiMWNd9lDyBUStIq/8PuOW33aOqmvFpqI=" crossorigin="anonymous"></script>
    <!-- icheck checkboxes -->
    <script type="text/javascript" src="<?php echo e(asset('icheck/icheck.min.js')); ?>"></script>

    <!-- Delay table load until everything else is loaded -->
    <script>
        $(window).load(function(){
            $('#postTable').removeAttr('style');
        })
    </script>

    <script>
        $(document).ready(function(){
            $('.published').iCheck({
                checkboxClass: 'icheckbox_square-yellow',
                radioClass: 'iradio_square-yellow',
                increaseArea: '20%'
            });
            $('.published').on('ifClicked', function(event){
                id = $(this).data('id');
                $.ajax({
                    type: 'POST',
                    url: "<?php echo e(URL::route('changeStatus')); ?>",
                    data: {
                        '_token': $('input[name=_token]').val(),
                        'id': id
                    },
                    success: function(data) {
                        // empty
                    },
                });
            });
            $('.published').on('ifToggled', function(event) {
                $(this).closest('tr').toggleClass('warning');
            });
        });
        
   

    </script>

</body>
</html>